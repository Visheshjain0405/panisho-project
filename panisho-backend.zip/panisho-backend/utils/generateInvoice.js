const PDFDocument = require('pdfkit');
const axios = require('axios');

async function fetchImageBuffer(url) {
  try {
    const res = await axios.get(url, { responseType: 'arraybuffer', timeout: 10000 });
    return Buffer.from(res.data, 'binary');
  } catch (error) {
    console.warn(`Failed to fetch image: ${url}`, error.message);
    return null;
  }
}

async function fetchLogoBuffer() {
  // Updated logo URL for Lotus Beauty - you can replace this with your actual logo
  const logoUrl = 'https://res.cloudinary.com/dvqgcj6wn/image/upload/v1750615825/panisho_logo__page-0001-removebg-preview_hdipnw.png';
  return await fetchImageBuffer(logoUrl);
}

exports.generateInvoicePDFBuffer = async (order) => {
  const doc = new PDFDocument({ 
    margin: 50,
    size: 'A4',
    info: {
      Title: `Tax Invoice - ${order._id}`,
      Author: 'Lotus Beauty Products',
      Subject: 'Tax Invoice'
    }
  });
  
  const buffers = [];
  doc.on('data', buffers.push.bind(buffers));
  doc.on('end', () => { });

  // Pink Lotus Color Theme (Updated for Lotus Beauty)
  const primaryPink = '#ad1457';  // Main brand color
  const lightPink = '#fce4ec';    // Light background
  const darkPink = '#7b1fa2';     // Dark accents
  const accentPink = '#f8bbd9';   // Medium accent
  const lotusGold = '#ff9800';    // Gold for highlights
  const darkText = '#2c2c2c';
  const mediumGray = '#666666';
  
  const pageWidth = doc.page.width - 100;
  let currentY = 60;

  // Helper functions
  const drawBox = (x, y, width, height, fillColor = 'white', borderColor = primaryPink) => {
    doc.save()
       .fillColor(fillColor)
       .rect(x, y, width, height)
       .fill()
       .strokeColor(borderColor)
       .lineWidth(2)
       .rect(x, y, width, height)
       .stroke()
       .restore();
  };

  try {
    // === MAIN HEADER ===
    // Company Logo and Details (Left)
    drawBox(50, currentY, 240, 120, lightPink);
    
    const logoBuffer = await fetchLogoBuffer();
    if (logoBuffer) {
      try {
        doc.image(logoBuffer, 60, currentY + 10, { width: 50, height: 50 });
      } catch (err) {
        // Lotus emoji as fallback
        doc.fontSize(24).fillColor(primaryPink).font('Helvetica-Bold')
           .text('🪷', 60, currentY + 25);
      }
    } else {
      // Lotus emoji as fallback
      doc.fontSize(24).fillColor(primaryPink).font('Helvetica-Bold')
         .text('🪷', 60, currentY + 25);
    }

    doc.fontSize(16).fillColor(primaryPink).font('Helvetica-Bold')
       .text('LOTUS BEAUTY', 120, currentY + 10);
    
    doc.fontSize(10).fillColor(darkPink).font('Helvetica-Bold')
       .text('Premium Skincare & Beauty Products', 120, currentY + 28);
    
    doc.fontSize(9).fillColor(darkText).font('Helvetica')
       .text('Shop No. 456, Lotus Garden Complex', 120, currentY + 42)
       .text('Beauty Boulevard, Surat - 395001', 120, currentY + 54)
       .text('Gujarat, India', 120, currentY + 66)
       .text('Phone: +91 99999 88888', 120, currentY + 78)
       .text('Email: info@lotusbeauty.com', 120, currentY + 90)
       .text('GSTIN: 24XXXXX1234X1ZX', 120, currentY + 102);

    // TAX INVOICE Title (Center)
    drawBox(300, currentY + 30, 120, 50, primaryPink);
    doc.fontSize(16).fillColor('white').font('Helvetica-Bold')
       .text('TAX INVOICE', 305, currentY + 48);
    
    // Add lotus symbol
    doc.fontSize(14).fillColor('white')
       .text('🌸', 360, currentY + 35);

    // Invoice Details (Right)
    drawBox(430, currentY, 145, 120, accentPink);
    
    const orderIdString = order._id ? order._id.toString() : 'UNKNOWN';
    const invoiceNumber = `LB-${orderIdString.slice(-8).toUpperCase()}`;
    
    doc.fontSize(9).fillColor(darkText).font('Helvetica-Bold')
       .text('Invoice No:', 440, currentY + 10)
       .text('Invoice Date:', 440, currentY + 25)
       .text('Due Date:', 440, currentY + 40)
       .text('Order ID:', 440, currentY + 55)
       .text('Payment Mode:', 440, currentY + 70)
       .text('Customer Type:', 440, currentY + 85);

    doc.font('Helvetica')
       .text(invoiceNumber, 510, currentY + 10)
       .text(new Date(order.createdAt || Date.now()).toLocaleDateString('en-IN'), 510, currentY + 25)
       .text('Immediate', 510, currentY + 40)
       .text(`#${orderIdString.slice(-6)}`, 510, currentY + 55)
       .text((order.paymentMethod || 'COD').toUpperCase(), 510, currentY + 70)
       .text('Retail', 510, currentY + 85);

    currentY += 140;

    // === SHIP TO SECTION ===
    drawBox(50, currentY, pageWidth, 90, lightPink);
    
    doc.fontSize(12).fillColor(primaryPink).font('Helvetica-Bold')
       .text('🚚 SHIP TO', 60, currentY + 10);

    // Add decorative lotus
    doc.fontSize(10).fillColor(lotusGold)
       .text('🌸', 520, currentY + 10);

    const firstName = order.user?.firstName || 'Valued';
    const lastName = order.user?.lastName || 'Customer';
    const email = order.user?.email || 'customer@email.com';
    const street = order.address?.street || 'Customer Address';
    const city = order.address?.city || 'Surat';
    const state = order.address?.state || 'Gujarat';
    const pincode = order.address?.pincode || '395001';
    const phone = order.address?.phone || '+91 XXXXXXXXXX';
    const shipToName = order.address?.name || `${firstName} ${lastName}`;

    doc.fontSize(11).fillColor(darkText).font('Helvetica-Bold')
       .text(shipToName, 60, currentY + 30);
    
    doc.fontSize(9).font('Helvetica')
       .text(street, 60, currentY + 45)
       .text(`${city}, ${state} - ${pincode}`, 60, currentY + 57)
       .text(`📞 ${phone}`, 60, currentY + 69)
       .text(`✉️ ${email}`, 250, currentY + 69);

    currentY += 110;

    // === ITEMS TABLE ===
    // Table Header
    drawBox(50, currentY, pageWidth, 30, primaryPink);
    doc.fontSize(10).fillColor('white').font('Helvetica-Bold')
       .text('S.No', 60, currentY + 10)
       .text('PRODUCT DESCRIPTION', 100, currentY + 10)
       .text('HSN', 300, currentY + 10)
       .text('QTY', 340, currentY + 10)
       .text('RATE (₹)', 380, currentY + 10)
       .text('DISC %', 430, currentY + 10)
       .text('AMOUNT (₹)', 480, currentY + 10);

    currentY += 30;

    // Table Items (Using actual products from order)
    const items = order.items || [];
    let itemNo = 1;
    let subtotalCalc = 0;
    let totalDiscount = 0;
    
    for (const item of items) {
      const product = item.product || {};
      let productName = product.name || 'Unknown Product';
      
      // Add product details for beauty products
      const volume = product.volume || '';
      const volumeUnit = product.volumeUnit || '';
      const targetAudience = product.targetAudience || '';
      const productTypes = product.productTypes || [];
      
      // Create detailed product description
      let productDescription = productName;
      if (volume && volumeUnit) {
        productDescription += ` (${volume}${volumeUnit})`;
      }
      if (targetAudience && targetAudience !== 'Unisex') {
        productDescription += ` - For ${targetAudience}`;
      }
      if (productTypes.length > 0) {
        productDescription += `\n${productTypes.slice(0, 2).join(', ')}`;
      }

      const mrp = product.mrp || 0;
      const sellingPrice = product.sellingPrice || 0;
      const quantity = item.quantity || 1;
      const discount = mrp > sellingPrice ? Math.round(((mrp - sellingPrice) / mrp) * 100) : 0;
      const lineAmount = quantity * sellingPrice;
      const discountAmount = quantity * (mrp - sellingPrice);
      
      subtotalCalc += lineAmount;
      totalDiscount += discountAmount;

      // Dynamic row height based on content
      const rowHeight = productTypes.length > 0 ? 40 : 30;
      
      // Table row
      const rowColor = itemNo % 2 === 0 ? '#f9f9f9' : 'white';
      drawBox(50, currentY, pageWidth, rowHeight, rowColor, '#e0e0e0');

      doc.fontSize(9).fillColor(darkText).font('Helvetica')
         .text(itemNo.toString(), 60, currentY + 8)
         .text(productDescription, 100, currentY + 5, { width: 190 })
         .text('3304', 305, currentY + 8) // HSN for cosmetics
         .text(quantity.toString(), 345, currentY + 8)
         .text(`₹${sellingPrice.toLocaleString()}`, 380, currentY + 8)
         .text(`${discount}%`, 435, currentY + 8)
         .text(`₹${lineAmount.toLocaleString()}`, 485, currentY + 8);

      currentY += rowHeight;
      itemNo++;
    }

    // Add empty rows if needed (minimum 8 rows for professional look)
    const minRows = 8;
    while (itemNo <= minRows) {
      const rowColor = itemNo % 2 === 0 ? '#f9f9f9' : 'white';
      drawBox(50, currentY, pageWidth, 30, rowColor, '#e0e0e0');
      currentY += 30;
      itemNo++;
    }

    currentY += 20;

    // === TOTALS SECTION ===
    // Amount in words
    const totalAmount = order.total || subtotalCalc;
    const tax = order.tax || Math.round(subtotalCalc * 0.18);
    const shipping = order.shipping || 0;
    
    drawBox(50, currentY, 350, 60, lightPink);
    doc.fontSize(10).fillColor(darkText).font('Helvetica-Bold')
       .text('Amount in Words:', 60, currentY + 10);
    doc.fontSize(9).font('Helvetica')
       .text(`Rupees ${convertNumberToWords(totalAmount)} Only`, 60, currentY + 25, { width: 330 });
    
    // Add thank you note
    doc.fontSize(8).fillColor(primaryPink).font('Helvetica-Bold')
       .text('🌸 Thank you for choosing Lotus Beauty! 🌸', 60, currentY + 45);

    // Summary totals
    drawBox(410, currentY, 165, 120, accentPink);
    
    const cgst = Math.round(tax / 2);
    const sgst = Math.round(tax / 2);

    doc.fontSize(9).fillColor(darkText).font('Helvetica')
       .text('Subtotal:', 420, currentY + 10)
       .text(`₹${subtotalCalc.toLocaleString()}`, 520, currentY + 10, { align: 'right' });
    
    if (totalDiscount > 0) {
      doc.text('Total Discount:', 420, currentY + 25)
         .text(`-₹${totalDiscount.toLocaleString()}`, 520, currentY + 25, { align: 'right' });
    }
    
    doc.text('CGST (9%):', 420, currentY + 40)
       .text(`₹${cgst.toLocaleString()}`, 520, currentY + 40, { align: 'right' })
       .text('SGST (9%):', 420, currentY + 55)
       .text(`₹${sgst.toLocaleString()}`, 520, currentY + 55, { align: 'right' })
       .text('Shipping:', 420, currentY + 70)
       .text(shipping === 0 ? 'FREE 🎁' : `₹${shipping.toLocaleString()}`, 520, currentY + 70, { align: 'right' });

    // Grand Total with decorative border
    doc.fillColor(primaryPink).rect(410, currentY + 85, 165, 30).fill();
    doc.fontSize(12).fillColor('white').font('Helvetica-Bold')
       .text('GRAND TOTAL:', 420, currentY + 95)
       .text(`₹${totalAmount.toLocaleString()}`, 520, currentY + 95, { align: 'right' });

    currentY += 140;

    // === TERMS AND CONDITIONS ===
    drawBox(50, currentY, pageWidth, 120, lightPink);
    
    doc.fontSize(12).fillColor(primaryPink).font('Helvetica-Bold')
       .text('🌸 TERMS AND CONDITIONS 🌸', 60, currentY + 10);

    const terms = [
      '• NO RETURN POLICY: All sales are final. Products once sold will not be taken back or exchanged due to hygiene reasons.',
      '• NO REFUND POLICY: We do not offer refunds under any circumstances. All transactions are final.',
      '• PRODUCT AUTHENTICITY: All products are 100% authentic and sourced from certified manufacturers.',
      '• QUALITY ASSURANCE: Products are dermatologically tested and meet international standards.',
      '• PATCH TEST: We recommend conducting a patch test before first use, especially for sensitive skin.',
      '• SHELF LIFE: Check product packaging for expiry dates. Use within recommended timeframe.',
      '• DISPUTE RESOLUTION: All disputes are subject to Surat, Gujarat jurisdiction only.',
      '• CUSTOMER SUPPORT: For queries contact: support@lotusbeauty.com | +91-99999-88888'
    ];

    doc.fontSize(8).fillColor(darkText).font('Helvetica');
    let termY = currentY + 25;
    terms.forEach(term => {
      doc.text(term, 60, termY, { width: pageWidth - 20 });
      termY += 12;
    });

    currentY += 140;

    // === SIGNATURE SECTION ===
    drawBox(350, currentY, 225, 80, accentPink);
    
    doc.fontSize(10).fillColor(darkText).font('Helvetica')
       .text('For LOTUS BEAUTY PRODUCTS', 360, currentY + 10);

    doc.fontSize(14).fillColor(primaryPink).font('Helvetica-Bold')
       .text('🪷 Digitally Signed 🪷', 360, currentY + 25);

    doc.fontSize(8).fillColor(mediumGray).font('Helvetica')
       .text('Authorized Signatory', 360, currentY + 45)
       .text(`Date: ${new Date().toLocaleDateString('en-IN')}`, 360, currentY + 57)
       .text('Natural • Organic • Cruelty-Free', 360, currentY + 69);

    // Footer with lotus theme
    doc.fontSize(8).fillColor(mediumGray).font('Helvetica')
       .text('This is a computer generated invoice and does not require physical signature.', 50, doc.page.height - 50, { 
         align: 'center', 
         width: pageWidth 
       });

    doc.fontSize(10).fillColor(primaryPink).font('Helvetica-Bold')
       .text('🌺 Stay Beautiful Naturally with Lotus Beauty 🌺', 50, doc.page.height - 35, { 
         align: 'center', 
         width: pageWidth 
       });

    doc.fontSize(8).fillColor(darkPink).font('Helvetica')
       .text('Visit us: www.lotusbeauty.com | Follow: @LotusBeautyOfficial | #NaturalBeauty #OrganicSkincare', 50, doc.page.height - 20, { 
         align: 'center', 
         width: pageWidth 
       });

  } catch (error) {
    console.error('Error generating invoice:', error);
    doc.fontSize(16).fillColor('red').text('Error generating invoice. Please contact support.', 50, 100);
  }

  doc.end();

  return new Promise((resolve, reject) => {
    doc.on('end', () => resolve(Buffer.concat(buffers)));
    doc.on('error', reject);
  });
};

// Helper function to convert numbers to words (Indian numbering system)
function convertNumberToWords(num) {
  if (num === 0) return 'Zero';
  
  const ones = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine'];
  const teens = ['Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const tens = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  
  function convertHundreds(n) {
    let result = '';
    
    if (n >= 100) {
      result += ones[Math.floor(n / 100)] + ' Hundred ';
      n %= 100;
    }
    
    if (n >= 20) {
      result += tens[Math.floor(n / 10)] + ' ';
      n %= 10;
    } else if (n >= 10) {
      result += teens[n - 10] + ' ';
      return result.trim();
    }
    
    if (n > 0) {
      result += ones[n] + ' ';
    }
    
    return result.trim();
  }
  
  // Indian numbering system: ones, thousands, lakhs, crores
  if (num < 1000) return convertHundreds(num);
  if (num < 100000) {
    const thousands = Math.floor(num / 1000);
    const remainder = num % 1000;
    let result = convertHundreds(thousands) + ' Thousand';
    if (remainder > 0) result += ' ' + convertHundreds(remainder);
    return result;
  }
  if (num < 10000000) {
    const lakhs = Math.floor(num / 100000);
    const remainder = num % 100000;
    let result = convertHundreds(lakhs) + ' Lakh';
    if (remainder >= 1000) {
      result += ' ' + convertHundreds(Math.floor(remainder / 1000)) + ' Thousand';
      remainder = remainder % 1000;
    }
    if (remainder > 0) result += ' ' + convertHundreds(remainder);
    return result;
  }
  if (num < 1000000000) {
    const crores = Math.floor(num / 10000000);
    const remainder = num % 10000000;
    let result = convertHundreds(crores) + ' Crore';
    if (remainder >= 100000) {
      result += ' ' + convertHundreds(Math.floor(remainder / 100000)) + ' Lakh';
      remainder = remainder % 100000;
    }
    if (remainder >= 1000) {
      result += ' ' + convertHundreds(Math.floor(remainder / 1000)) + ' Thousand';
      remainder = remainder % 1000;
    }
    if (remainder > 0) result += ' ' + convertHundreds(remainder);
    return result;
  }
  
  return 'Amount Too Large';
}