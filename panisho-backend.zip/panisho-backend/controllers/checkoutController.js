const Razorpay = require('razorpay');
const crypto = require('crypto');
const Order = require('../models/Order');
const Address = require('../models/Address');
const User = require('../models/User');
const CartItem = require('../models/CartItem');
const { generateInvoicePDFBuffer } = require('../utils/generateInvoice');
const { uploadPDFBufferToCloudinary } = require('../utils/cloudinaryUpload');
const transporter = require('../config/mailer');
const { generateEmailHTML } = require('../utils/generateEmailHTML');
const axios = require('axios');

const razorpayInstance = new Razorpay({
  key_id: process.env.RAZORPAY_KEY_ID,
  key_secret: process.env.RAZORPAY_KEY_SECRET
});

// Send WhatsApp message
const sendWhatsAppMessage = async (mobile, orderId, amount, paymentMethod, items, deliveryDate, userName) => {
  if (!mobile || typeof mobile !== 'string' || mobile.trim() === '') {
    console.warn('Invalid or missing mobile number for WhatsApp message');
    return;
  }
  try {
    // Ensure phone number is in international format
    let phoneNumber = mobile.trim();
    if (!phoneNumber.startsWith('+')) {
      phoneNumber = `+91${phoneNumber}`; // Default to India (+91); adjust if supporting other countries
    }
    console.log(`Formatted phone number: ${phoneNumber}`);

    // Prepare items summary (e.g., "Item1 (2), Item2 (1)")
    const itemsSummary = items.map(item => `${item.product.name} (${item.quantity})`).join(', ');

    const message = {
      messaging_product: 'whatsapp',
      to: phoneNumber,
      type: 'template',
      template: {
        name: 'order_confirmed_panisho', // Must be an approved template
        language: { code: 'en' },
        components: [
          {
            type: 'body',
            parameters: [
              { type: 'text', text: userName || 'Customer' }, // {{1}} - Name
              { type: 'text', text: orderId },                 // {{2}} - Order ID
              { type: 'text', text: `₹${amount.toLocaleString()}` }, // {{3}} - Amount
              { type: 'text', text: paymentMethod || 'Unknown' },    // {{4}} - Payment Method
              { type: 'text', text: itemsSummary || 'N/A' },         // {{5}} - Items
              { type: 'text', text: deliveryDate || 'TBD' }          // {{6}} - Expected Delivery
            ]
          }
        ]
      }
    };

    await axios.post(
      `https://graph.facebook.com/v20.0/${process.env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
      message,
      {
        headers: {
          Authorization: `Bearer ${process.env.WHATSAPP_ACCESS_TOKEN}`,
          'Content-Type': 'application/json'
        }
      }
    );
    console.log(`WhatsApp message sent to ${phoneNumber} for order ${orderId}`);
  } catch (error) {
    console.error('WhatsApp message error:', {
      error: error.message,
      response: error.response?.data,
      mobile,
      orderId
    });
  }
};

// Place Order after success or for COD
exports.placeOrder = async (req, res) => {
  try {
    const userId = req.user._id;
    console.log('User ID:', userId);
    const { addressId, paymentMethod } = req.body;

    const user = await User.findById(userId).select('firstName mobile email');
    console.log('User data:', user);
    const address = await Address.findById(addressId);
    const cartItems = await CartItem.find({ userId }).populate('productId');

    if (!user || !address || !cartItems.length) {
      return res.status(400).json({ message: 'Invalid request: missing data' });
    }

    const subtotal = cartItems.reduce((sum, item) => sum + item.productId.sellingPrice * item.quantity, 0);
    const shipping = subtotal > 499 ? 0 : 99;
    const total = subtotal + shipping;


    const order = await Order.create({
      userId,
      addressId,
      items: cartItems.map(item => ({
        productId: item.productId._id,
        quantity: item.quantity
      })),
      paymentMethod,
      subtotal,
      shipping,
      total
    });
    console.log('User mobile:', user.mobile);

    // Send WhatsApp confirmation if mobile number is valid
    if (user.mobile && typeof user.mobile === 'string' && user.mobile.trim() !== '') {
      // Estimate delivery date (e.g., 3-5 days from today)
      const currentDate = new Date('2025-06-20T00:55:00Z'); // Current date and time (12:55 AM IST, June 20, 2025)
      const deliveryDate = new Date(currentDate);
      deliveryDate.setDate(currentDate.getDate() + 3); // Minimum 3 days
      const formattedDeliveryDate = deliveryDate.toLocaleDateString('en-GB', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });

      await sendWhatsAppMessage(
        user.mobile,
        order._id,
        total,
        paymentMethod,
        cartItems.map(item => ({ product: item.productId, quantity: item.quantity })),
        formattedDeliveryDate,
        user.firstName
      );
    } else {
      console.warn(`No valid mobile number for user ${userId}, skipping WhatsApp message`);
    }

    // Generate and send invoice
    const pdfBuffer = await generateInvoicePDFBuffer({
      ...order.toObject(),
      address,
      user,
      items: cartItems.map(item => ({
        product: item.productId,
        quantity: item.quantity
      }))
    });

    const invoiceUrl = await uploadPDFBufferToCloudinary(pdfBuffer, `invoice-${order._id}`);
    order.invoiceUrl = invoiceUrl;
    await order.save();

    await transporter.sendMail({
      from: `"Panisho" <${process.env.EMAIL_USER}>`,
      to: user.email,
      subject: '🧾 Your Panisho Order Invoice',
      html: generateEmailHTML({
        order: {
          ...order.toObject(),
          items: cartItems.map(item => ({
            product: item.productId,
            quantity: item.quantity
          }))
        },
        user,
        address
      })
    });

    await CartItem.deleteMany({ userId });

    res.status(201).json({
      message: 'Order placed successfully',
      orderId: order._id,
      invoiceUrl
    });

  } catch (err) {
    console.error('Order error:', err);
    res.status(500).json({ message: 'Something went wrong!' });
  }
};

// Create Razorpay Order
exports.createRazorpayOrder = async (req, res) => {
  try {
    const { amount } = req.body;
    const options = {
      amount: amount * 100, // ₹ to paise
      currency: 'INR',
      receipt: `rcpt_${Math.floor(Math.random() * 100000)}`,
    };

    const order = await razorpayInstance.orders.create(options);
    res.json({ razorpayOrderId: order.id });

  } catch (error) {
    console.error("Razorpay order error:", error);
    res.status(500).json({ message: "Failed to create Razorpay order" });
  }
};

// Verify Razorpay Payment
exports.verifyPayment = async (req, res) => {
  try {
    const {
      razorpay_payment_id,
      razorpay_order_id,
      razorpay_signature,
      addressId,
      paymentMethod
    } = req.body;

    const hmac = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET);
    hmac.update(razorpay_order_id + '|' + razorpay_payment_id);
    const generated_signature = hmac.digest('hex');

    if (generated_signature !== razorpay_signature) {
      return res.status(400).json({ message: "Payment verification failed" });
    }

    req.body.paymentMethod = paymentMethod || 'razorpay';
    await exports.placeOrder(req, res);

  } catch (error) {
    console.error("Verification error:", error);
    res.status(500).json({ message: "Failed to verify payment" });
  }
};

// Send WhatsApp Confirmation
exports.sendWhatsAppConfirmation = async (req, res) => {
  try {
    const { phone, orderId, amount, paymentMethod, items, deliveryDate, userName } = req.body;
    if (!phone || typeof phone !== 'string' || phone.trim() === '') {
      return res.status(400).json({ message: 'Invalid or missing phone number' });
    }
    await sendWhatsAppMessage(phone, orderId, amount, paymentMethod, items, deliveryDate, userName);
    res.status(200).json({ message: 'WhatsApp message sent successfully' });
  } catch (error) {
    console.error('WhatsApp confirmation error:', error);
    res.status(500).json({ message: 'Failed to send WhatsApp message' });
  }
};