const CartItem = require('../models/CartItem');
const Product = require('../models/Product');

// Helper: enrich cart item with price + total
const enrichCart = (items) => {
  return items.map(item => {
    const product = item.productId;
    const variant = product?.variants?.[item.variantIndex ?? 0] || {};
    const quantity = item.quantity ?? 1;
    const price = variant?.sellingPrice || 0;
    const amount = price * quantity;

    return {
      _id: item._id,
      productId: product,
      variant,
      quantity,
      amount: price * quantity,
    };
  });
};

// ✅ GET all cart items for the current user
exports.getCart = async (req, res) => {
  try {
    const cartItems = await CartItem.find({ userId: req.user._id }).populate('productId');
    const enriched = enrichCart(cartItems);
    res.json(enriched);
  } catch (error) {
    res.status(500).json({ message: 'Failed to fetch cart items', error });
  }
};

// ✅ POST: Add product to cart
exports.addToCart = async (req, res) => {
  try {
    const { productId, quantity, variantIndex = 0 } = req.body;
    const userId = req.user._id;
    const qty = quantity ?? 1;

    // 🔥 FIXED: Check productId + variantIndex to distinguish variants
    let item = await CartItem.findOne({ userId, productId, variantIndex });

    if (item) {
      item.quantity += qty;
      await item.save();
    } else {
      item = new CartItem({ userId, productId, quantity: qty, variantIndex });
      await item.save();
    }

    const cartItems = await CartItem.find({ userId }).populate('productId');
    const enriched = enrichCart(cartItems);
    res.status(201).json(enriched);
  } catch (error) {
    res.status(500).json({ message: 'Failed to add to cart', error });
  }
};


// ✅ PUT: Update quantity of a cart item
exports.updateCart = async (req, res) => {
  try {
    const { itemId } = req.params;
    const { quantity } = req.body;

    const item = await CartItem.findOne({ _id: itemId, userId: req.user._id });
    if (!item) return res.status(404).json({ message: 'Item not found' });

    item.quantity = quantity;
    await item.save();

    const cartItems = await CartItem.find({ userId: req.user._id }).populate('productId');
    const enriched = enrichCart(cartItems);
    res.json(enriched);
  } catch (error) {
    res.status(500).json({ message: 'Failed to update cart item', error });
  }
};

// ✅ DELETE: Remove item from cart
exports.removeFromCart = async (req, res) => {
  try {
    const { itemId } = req.params;

    await CartItem.deleteOne({ _id: itemId, userId: req.user._id });

    const cartItems = await CartItem.find({ userId: req.user._id }).populate('productId');
    const enriched = enrichCart(cartItems);
    res.json(enriched);
  } catch (error) {
    res.status(500).json({ message: 'Failed to remove cart item', error });
  }
};
